# Blog Website - Core PHP

## Overview
This project is a simple blog website developed using Core PHP, following the MVC (Model-View-Controller) architecture. It enables users to perform CRUD operations on blog posts, offers a user authentication system, and includes a commenting feature for posts. The website is designed to be responsive, ensuring a seamless user experience across various devices.

## Features
- **User Authentication:** Allows users to register, log in, and log out.
- **Blog Post Management:** Supports Create, Read, Update, and Delete operations on blog posts.
- **Commenting System:** Users can leave comments on blog posts.
- **Responsive Design:** The website is optimized for accessibility on different devices.

## Requirements
- PHP (version 7.0 or higher)
- MySQL database
- Web server (e.g., Apache)
- (Optional) Composer for managing dependencies

## Installation

1. **Clone the Repository:**
   ```bashhttps://github.com/AMIT222001/blog.git
