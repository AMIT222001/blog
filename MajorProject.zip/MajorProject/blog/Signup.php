<?php
include "Config.php";

if (isset($_POST['add_user'])) {
	$username=mysqli_real_escape_string($config,$_POST['username']);
	$email=mysqli_real_escape_string($config,$_POST['email']);
	$pass=mysqli_real_escape_string($config,sha1($_POST['password']));
	$c_pass=mysqli_real_escape_string($config,sha1($_POST['c_pass']));
	$role=0;

	if (strlen($username) < 4 || strlen($username) > 100) {
		$error="username must be betweeb 4 to 100 char";
	}
	elseif (strlen($pass) < 4 ) {
		$error="password must be 4 char long";
	}
	elseif($pass!=$c_pass){
		$error="password does not match";
	}
	else
	{
		$sql="SELECT * FROM user WHERE email='$email'";
		$query=mysqli_query($config,$sql);
		$row=mysqli_num_rows($query);
		if ($row >= 1) {
			$error="Email already exist";
		}
		else
		{
			$sql2="INSERT INTO user (username,email,password,role) VALUES('$username','$email','$pass','$role')";
			$query2=mysqli_query($config,$sql2);
			if ($query2) {
				$msg='User has been added successfully';
				
		   		header("location:login.php");
			}
			else
			{
				$error="Failed, please try again";
			}
			// echo "User added successfully";
		}
	}
}
?>
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
    <!-- Bootstrap CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-1BmE4kWBq78iYhFldvKuhfTAU6auU8tT94WrHftjDbrCEXSU1oBoqyl2QvZ6jIW3" crossorigin="anonymous">
<div class="container">
	<div class="row">
		<div class="col-md-5 m-auto bg-info p-4">
			<?php 
			if (!empty($error)) {
				echo "<p class='bg-danger text-white p-2'>".$error."</p>";
			}
			if (!empty($msg)) {
				echo "<p class='bg-success text-white p-2'>".$msg."</p>";
			}
			?>
			<form action="" method="POST">
				<p class="text-center">Create new user</p>
				<div class="mb-3">
					<input type="text" name="username" placeholder="Username" class="form-control" required value="<?= (!empty($error))? $username:''; ?>">
				</div>
				<div class="mb-3">
					<input type="email" name="email" placeholder="Email" class="form-control" required value="<?= (!empty($error))? $email:''; ?>">
				</div>
				<div class="mb-3">
					<input type="password" name="password" placeholder="Password" class="form-control" required>
				</div>
				<div class="mb-3">
					<input type="password" name="c_pass" placeholder="Confirm Password" class="form-control" required>
				</div>
				
				<div class="mb-3">
					<input type="submit" name="add_user" class="btn btn-primary" value="Create">
				</div>
			</form>
		</div>
	</div>
</div>
