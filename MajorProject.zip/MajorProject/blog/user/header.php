<?php
$page=basename($_SERVER['PHP_SELF'],".php");
include "Config.php";
$select="SELECT * FROM categories";
$query=mysqli_query($config,$select);
session_start();

?>
<!doctype html>
<html lang="en">
  <head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="stylesheet" type="text/css" href="style.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
    <!-- Bootstrap CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-1BmE4kWBq78iYhFldvKuhfTAU6auU8tT94WrHftjDbrCEXSU1oBoqyl2QvZ6jIW3" crossorigin="anonymous">
    
    <script src='https://kit.fontawesome.com/a076d05399.js' crossorigin='anonymous'></script>

<style>
  body{
    margin:0;
    padding:0;
    position: relative;
    /* background-color: hsl(0, 0%, 94%); */
    background-color: black;
    
  }
  ul li
  {
    padding:5px;
  }
 
</style>
    <title>Blog</title>
  </head>
  <body class="">
    <nav class="navbar navbar-expand-lg navbar-dark bg-dark">
  <div class="container">
    <a class="navbar-brand" href="#"><svg width="50" height="35"version="1.1" id="Layer_1" xmlns="http://www.w3.org/2000/svg" x="0" y="0" viewBox="0 0 128 128" style="enable-background:new 0 0 128 128" xml:space="preserve"><style>.st4{fill:#ffa77b}.st6{fill:#746887}.st7{fill:#f98770}</style><path d="M123.5 20.5H97.024v46.579H84.091V20.5H4.5a3 3 0 0 0-3 3v100a3 3 0 0 0 3 3h119a3 3 0 0 0 3-3v-100a3 3 0 0 0-3-3z" style="fill:#f6f7f7"/><path style="fill:#ffcfb8" d="M97.024 67.079H84.091V47.22H14v43.988h100V47.22H97.024z"/><path d="M90.557 1.499a6.47 6.47 0 0 0-6.466 6.466v59.114h12.933V7.965a6.47 6.47 0 0 0-6.467-6.466z" style="fill:#cff1fb"/><path class="st4" d="M1.5 23.482v10.934h82.591V20.5H4.482A2.978 2.978 0 0 0 1.5 23.482zM123.518 20.5H97.024v13.916H126.5V23.482a2.978 2.978 0 0 0-2.982-2.982zM90.526 78.149l6.498-11.073H84.091zM90.557 1.5a6.462 6.462 0 0 0-6.448 6.097h12.896A6.46 6.46 0 0 0 90.557 1.5z"/><g><path class="st7" d="M84.091 19H4.482A4.488 4.488 0 0 0 0 23.482v10.934a1.5 1.5 0 0 0 1.5 1.5h82.591a1.5 1.5 0 0 0 1.5-1.5V20.5a1.5 1.5 0 0 0-1.5-1.5zm-1.5 13.916H3v-9.434C3 22.665 3.665 22 4.482 22H82.59v10.916zM123.518 19H97.023a1.5 1.5 0 0 0-1.5 1.5v13.916a1.5 1.5 0 0 0 1.5 1.5H126.5a1.5 1.5 0 0 0 1.5-1.5V23.482A4.488 4.488 0 0 0 123.518 19zM125 32.916H98.523V22h24.994c.817 0 1.482.665 1.482 1.482v9.434z"/><path class="st6" d="M123.5 19H97.023a1.5 1.5 0 0 0-1.5 1.5v45.079H85.59V20.5a1.5 1.5 0 0 0-1.5-1.5H4.5A4.505 4.505 0 0 0 0 23.5v19.235a1.5 1.5 0 0 0 3 0V23.5c0-.827.673-1.5 1.5-1.5h78.091v45.079a1.5 1.5 0 0 0 1.5 1.5h12.933a1.5 1.5 0 0 0 1.5-1.5V22H123.5c.827 0 1.5.673 1.5 1.5v100c0 .827-.673 1.5-1.5 1.5h-8.063a1.5 1.5 0 0 0 0 3h8.063c2.481 0 4.5-2.019 4.5-4.5v-100c0-2.481-2.019-4.5-4.5-4.5zM107.737 125H4.5c-.827 0-1.5-.673-1.5-1.5V50.672a1.5 1.5 0 0 0-3 0V123.5c0 2.481 2.019 4.5 4.5 4.5h103.237a1.5 1.5 0 0 0 0-3z"/><path class="st6" d="M14.422 25.958H11.44a1.5 1.5 0 0 0 0 3h2.982a1.5 1.5 0 0 0 0-3zM23.367 25.958h-2.981a1.5 1.5 0 0 0 0 3h2.981a1.5 1.5 0 0 0 0-3z"/><path class="st7" d="M114 45.721H97.023a1.5 1.5 0 0 0-1.5 1.5v18.358H85.59V47.221a1.5 1.5 0 0 0-1.5-1.5H14a1.5 1.5 0 0 0-1.5 1.5v43.987a1.5 1.5 0 0 0 1.5 1.5h100a1.5 1.5 0 0 0 1.5-1.5V72.23a1.5 1.5 0 0 0-3 0v17.478h-97V48.721h67.091v18.358a1.5 1.5 0 0 0 1.5 1.5h12.933a1.5 1.5 0 0 0 1.5-1.5V48.721H112.5V64.34a1.5 1.5 0 0 0 3 0V47.221a1.5 1.5 0 0 0-1.5-1.5z"/><path class="st7" d="M90.558 6.096a1.5 1.5 0 0 0-1.5 1.5v59.48a1.5 1.5 0 0 0 3 0V7.596a1.5 1.5 0 0 0-1.5-1.5z"/><path class="st6" d="M90.557-.001c-4.393.004-7.966 3.577-7.966 7.967v59.113a1.5 1.5 0 0 0 1.5 1.5h12.933a1.5 1.5 0 0 0 1.5-1.5V7.966c-.001-4.39-3.574-7.963-7.967-7.967zm4.966 65.58H85.59V7.966a4.976 4.976 0 0 1 4.966-4.967 4.976 4.976 0 0 1 4.967 4.967v57.613z"/><path class="st6" d="M97.024 65.576H84.091a1.5 1.5 0 0 0-1.297 2.254l6.435 11.073a1.5 1.5 0 0 0 1.294.746h.003c.532 0 1.024-.282 1.294-.741l6.499-11.073a1.502 1.502 0 0 0-1.295-2.259zm-6.492 9.599-3.835-6.599h7.707l-3.872 6.599zM90.558 0c-4.216 0-7.706 3.3-7.946 7.512a1.502 1.502 0 0 0 1.498 1.585h12.896a1.5 1.5 0 0 0 1.498-1.585C98.264 3.3 94.774 0 90.558 0zm-4.595 6.097C86.703 4.274 88.49 3 90.558 3s3.854 1.274 4.595 3.097h-9.19zM108 102.5H16a1.5 1.5 0 0 0 0 3h92a1.5 1.5 0 0 0 0-3zM108 114.5H16a1.5 1.5 0 0 0 0 3h92a1.5 1.5 0 0 0 0-3zM68 54.5H24a1.5 1.5 0 0 0 0 3h44a1.5 1.5 0 0 0 0-3zM68 66.5H24a1.5 1.5 0 0 0 0 3h44a1.5 1.5 0 0 0 0-3zM68 78.5H24a1.5 1.5 0 0 0 0 3h44a1.5 1.5 0 0 0 0-3z"/></g></svg><strong> BLOGS</strong></a>
    <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarColor02" aria-controls="navbarColor02" aria-expanded="false" aria-label="Toggle navigation">
      <span class="navbar-toggler-icon"></span>
    </button>

    <div class="collapse navbar-collapse" id="navbarColor02">
      <ul class="navbar-nav me-auto">
        <li class="nav-item">
          <a class="nav-link <?= ($page=="index")? 'active':''; ?>" href="index.php">Home
            <span class="visually-hidden">(current)</span>
          </a>
        </li>
        
        <li class="nav-item dropdown">
          <a class="nav-link dropdown-toggle" data-bs-toggle="dropdown" href="#" role="button" aria-haspopup="true" aria-expanded="false">Categories</a>
          <div class="dropdown-menu">
             <?php while($cats=mysqli_fetch_assoc($query)) {?>
            <a class="dropdown-item" href="category.php?id=<?= $cats['cat_id'] ?>">
              <?= $cats['cat_name'] ?>
            </a>
            <?php } ?>
          </div>
        </li>
        <li class="nav-item">
          <a class="nav-link <?= ($page=="login")? 'active':''; ?>" href="../login.php">
          <?php
          // session_start();
           if(isset($_SESSION['user_data']['2']))
          {
           
            echo "Dashboard";
          }
          else
          {
            echo "Login";
          }
         
          ?>
          
          </a>
        </li>
        <li class="nav-item">
          <a class="nav-link" href="./logout.php">  Logout</a>
       
          
         
        </li>
      </ul>
      <?php 
       if (isset($_GET['keyword'])) {
         $keyword=$_GET['keyword'];
       }
       else
       {
        $keyword="";
       }
      ?>
      <form class="d-flex" action="search.php" method="GET">
        <input class="form-control me-sm-2" type="text" placeholder="Search" name="keyword" required maxlength="70" autocomplete="off" value="<?= $keyword ?>">
        <button class="btn btn-secondary my-2 my-sm-0" type="submit">Search</button>
      </form>
    </div>
  </div>
</nav>