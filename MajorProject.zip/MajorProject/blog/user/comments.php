<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-T3c6CoIi6uLrA9TneNEoa7RxnatzjcDSCmG1MXxSR1GAsXEV/Dwwykc2MPK8M2HN" crossorigin="anonymous">
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js" integrity="sha384-C6RzsynM9kWDrMNeT87bh95OGNyZPhcTNXj1NW7RuBCsyN/o0jlpcV8Qyq46cDfL" crossorigin="anonymous"></script>
    <script src="jquery-3.7.1.min.js"></script>
    <?php
    session_start();
    include("config.php");

     $_SESSION["user_data"][0];

   
          $blogId=$_GET['id'];
         
        $sql=  "SELECT c.comment_id, c.comment_text, c.created_at, u.username
          FROM comment c
          INNER JOIN user u ON c.user_id = u.user_id WHERE c.blog_id = '$blogId'"; // Replace 1 with the actual blog ID you want to display comments for

    $result = mysqli_query($config,$sql);
$comments = [];




    ?>
    <style>
        .html
        {
            font-size:62.5%
        }
        .add-comments
        {
            font-size: 1.5rem;
            text-decoration: none;
            background-color: blue;
            color: white;
           
            box-shadow: rgba(0, 0, 0, 0.35) 0px 5px 15px;
            border-radius: 10px;
            transition: all 1s linear;
           
        }
        .hero
        {
            background-color: skyblue;
        }
        .add-comments:hover
        {
            &::after
            {
                content: ">>>";
            }
            background-color: red;
            font-size: 1.6rem;
            
            
        }
        
.comment
{
    
    border: solid 1px;
    box-shadow: rgba(99, 99, 99, 0.2) 0px 2px 8px 0px;
    height: 100px;
}
.edit
{
    float: right;
    background-color: green;
    font-size: 1rem;
    text-decoration: none;
    color: white;
    transition:  all 1s linear;
}
.edit:hover
{
    background-color: red;
}
.close
{
    float: right;
   background-color: red;
   color: white;
   text-decoration: none;
   border-radius: 10px;
   z-index: 1;
    font-size: 1.5rem;
   
  font-weight: 700;
  
}
.nothing
{
    font-size: 2rem;
    font-weight: 700;
    color: grey;
    

}
.nothing-image
{
    height: 100vh;
    aspect-ratio: 1;
    transition: all 3s linear;
}
.nothing-image:hover
{
    transform:scale(1.2) ;
}
    </style>
</head>
<body>


    <div class="container-fluid">
   
        <div class="row">
            <div class="col hero">
            <a class="add-comments" href="./Addcomment.php?id=<?php echo $_GET['id'];?>">Click To Add Comments</a>
            <a href="./index.php" class="close bg-danger">X</a>
            </div>
           
         

           
           
        </div>
      
    </div>
    <div class="container-fluid">
    <div class="row">
    
    <?php
        if (mysqli_num_rows($result)> 0) {
    while ( $row=mysqli_fetch_assoc($result)) {
    $comments[] = $row;
   
    ?>
    <div class="col-12 comment">
     <strong> <?php echo $row["username"]?>:</strong><span> <?php echo $row["created_at"]?></span>
     <br>
     <hr>
     <span> <?php
  echo $row["comment_text"];
  ?></span>
  <a href="" class="edit ">Edit</a>
     </div>
    
     <?php
  
  
    
   
  
}
}
else
{
    

?>
<div class="col-12 nothing">
    --------No comment Availaible------
</div>
<div class="col-12 nothing">
   <img class="nothing-image" src="./notfound.jpg" alt="">
</div>
<?php
}
?>
    
  
    </div>
    
    </div>
</body>
</html>