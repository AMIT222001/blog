<?php
include("config.php");
if (isset($_POST['user_id']) && isset($_POST['blog_id']))
{
    $userId = $_POST['user_id'];
    $blogId = $_POST['blog_id'];
    $checkQuery = "SELECT * FROM likes WHERE user_id = $userId AND blog_id = $blogId";
    $checkResult = mysqli_query($config, $checkQuery);
    if (mysqli_num_rows($checkResult) == 0) {
        // The combination doesn't exist; insert a new like
        $insertQuery = "INSERT INTO likes (user_id, blog_id) VALUES ($userId, $blogId)";
        $insertResult = mysqli_query($config, $insertQuery);
       $countQuery = "SELECT COUNT(*) AS like_count FROM likes WHERE blog_id = $blogId";
       $countResult = mysqli_query($config, $countQuery);
       $likecount=0;
        if ($countResult) {
          $row = mysqli_fetch_assoc($countResult);
         $likeCount = $row['like_count'];
   
           
        } 
      
        if ($insertResult) {
            echo $likeCount ."Liked";
             // Return a success response
        } else {
            echo "Error: " . mysqli_error($conn); // Return an error response
        }
    } else {
        // deleting 
        $checkQuery = "DELETE  FROM likes WHERE user_id = $userId AND blog_id = $blogId";
        $checkResult = mysqli_query($config, $checkQuery);
        // separation 
        $countQuery = "SELECT COUNT(*) AS like_count FROM likes WHERE blog_id = $blogId";
        $countResult = mysqli_query($config, $countQuery);
        $likecount=0;
         if ($countResult) {
           $row = mysqli_fetch_assoc($countResult);
          $likeCount = $row['like_count'];
      
         }
        echo $likeCount."disliked"; // Return a response indicating that the user has already liked this blog post

    }

}
?>