// $countQuery = "SELECT COUNT(*) AS like_count FROM likes WHERE blog_id = $blogId";
         $countResult = mysqli_query($config, $countQuery);
        $likecount=0;
         if ($countResult) {
           $row = mysqli_fetch_assoc($countResult);
          $likeCount = $row['like_count'];
    
            
         } 
       