<?php
include("config.php");

session_start();
$userId=$_SESSION['user_data'][0];



?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Comments</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-T3c6CoIi6uLrA9TneNEoa7RxnatzjcDSCmG1MXxSR1GAsXEV/Dwwykc2MPK8M2HN" crossorigin="anonymous">
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js" integrity="sha384-C6RzsynM9kWDrMNeT87bh95OGNyZPhcTNXj1NW7RuBCsyN/o0jlpcV8Qyq46cDfL" crossorigin="anonymous"></script>
    <script src="jquery-3.7.1.min.js"></script>
    <style>
        body
        {
            font-family: Arial ,sans-serif;
            
        }
        .comment {
            border: 1px solid #ccc;
            margin: 10px;
            padding: 10px;
        }
        .close-button
        {
            font-size: larger;
            background-color: red;
           color: white;
           font-weight:500;
            border-radius: 45%;
            float: right;
            padding:3px;
            text-decoration: none;
            margin: 4px;
        }
        
    </style>
</head>
<body>
<a class="close-button bg-danger" href="index.php">X</a>
    <div class="container">
    <h1>Welcome To Comment section</h1>
   
        <div class="row">
            <div class="col-6"><form id="comment-form" method="POST">
       
       <label for="comment-text">Comment:</label>
       <textarea id="comment-text" name="comment-text" rows="4"  required></textarea><br>
       <input type="submit" value="submit" name='submit'>
   </form></div>
            
        </div>

        

    </div>
   
  

   

   
</body>
</html>
<?php
// insert post comment 
if(isset($_POST['submit']))
{
    $comment=$_POST['comment-text'];
    $blogid=$_GET['id'];
   
    $sql="INSERT INTO comment (user_id,blog_id,comment_text)  VALUES ('$userId','$blogid','$comment')";
    $result=mysqli_query($config,$sql);
    if($result)
    {
   

      echo ' <div class="container">
        <div class="alert alert-success" role="alert">
            <strong>Success!</strong> The task was completed successfully.
        </div>
    </div>';
   
    }
    else
    {
        
        echo ' <div class="container">
        <div class="alert alert-danger" role="alert">
            <strong>Failed!</strong>to add your comment .
        </div>
    </div>';
    

    }
}


 
?>
