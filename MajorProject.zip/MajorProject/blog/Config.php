<?php
$config=mysqli_connect("localhost","root","","blog") or die("DB Not Connected");
?>