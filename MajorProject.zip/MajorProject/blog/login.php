<?php
ob_start();
include 'header.php';
include 'Config.php';
session_start();
if (isset($_SESSION['user_data'])) {
   header("location:http://localhost/blog/admin/index.php");
}
?>
<div class=" container">
	<div  class="row">
		<div style="border-radius:30px;box-shadow: rgba(50, 50, 93, 0.25) 0px 30px 60px -12px inset, rgba(0, 0, 0, 0.3) 0px 18px 36px -18px inset;" class="col-xl-5 col-md-4 m-auto p-5 mt-5 bg-info">
			<form action="" method="POST">
				<p style="font-weight:900;font-size:35px" class="text-center">Blog! Login your account.</p>
			<div  class="mb-3">
				<input style="border-radius:30px;box-shadow: rgba(50, 50, 93, 0.25) 0px 30px 60px -12px inset, rgba(0, 0, 0, 0.3) 0px 18px 36px -18px inset;font-weight:600" type="email" name="email" placeholder="Email" class="form-control" required>
			</div>
			<div class="mb-3">
				<input style="border-radius:30px;box-shadow: rgba(50, 50, 93, 0.25) 0px 30px 60px -12px inset, rgba(0, 0, 0, 0.3) 0px 18px 36px -18px inset;font-weight:600" type="password" name="password" placeholder="Password" class="form-control" required>
			</div>
			<div class="mb-3">
				<input style="border-radius:10px;
				margin-left:40%;box-shadow: rgba(6, 24, 44, 0.4) 0px 0px 0px 2px, rgba(6, 24, 44, 0.65) 0px 4px 6px -1px, rgba(255, 255, 255, 0.08) 0px 1px 0px inset;" type="submit" name="login_btn"class="btn btn-primary" value="Login">
			</div>
			<div class="mb-3 text-center">
			<a style="color:white;text-decoration:none;font-weight:600;" href="Signup.php">SignUp</a>
			</div>
			 <?php
			 if (isset($_SESSION['error'])) {
			 	$error=$_SESSION['error'];
			 	echo "<p class='bg-danger p-2 text-white'>".$error."</p>";
			 	unset($_SESSION['error']);
			 }
			 ?>
			</form>
		</div>
	</div>
</div>

<?php
if (isset($_POST['login_btn'])) {
	$email=mysqli_real_escape_string($config,$_POST['email']);
	$pass=mysqli_real_escape_string($config,sha1($_POST['password']));
	$sql="SELECT * FROM user WHERE email='{$email}' AND password='{$pass}'";
	$query=mysqli_query($config,$sql);
	$data=mysqli_num_rows($query);
	if ($data) {
		$result=mysqli_fetch_assoc($query);
		$user_data=array($result['user_id'],$result['username'],$result['role']);
		$_SESSION['user_data']=$user_data;
		if($result['role']==1)
		{
			header("location:admin/index.php");
		}
		else
		{
			header("location:user/index.php");
		}
	
	}
	else
	{ 
		
		$_SESSION['error']="Invalid email/password";
		header("location:login.php");
	}
}
ob_end_flush();
?>